	<!-- footer -->
	<div class="container">
		<hr>
		<footer>
			<p class="muted"><small>&copy; <?php echo date('Y'); ?> RELOADING</small></p>
		</footer>
	</div>
	</body>
</html>